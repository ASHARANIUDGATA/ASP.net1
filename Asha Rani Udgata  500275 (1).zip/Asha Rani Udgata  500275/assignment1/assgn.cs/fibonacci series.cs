﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fibonacci_series
{
    class Program
    {
        static void Main(string[] args)
        {
            int n, first = 0, second = 1, third = 0;
            Console.WriteLine("fibonacci series for first 10 numbers");
          
           for (int i=0; i <= 10; i++)
            {
                third = first + second;
                Console.WriteLine("{0}", third);
                first = second;
                second = third;
            }
            Console.ReadLine();

        }
    }
}
