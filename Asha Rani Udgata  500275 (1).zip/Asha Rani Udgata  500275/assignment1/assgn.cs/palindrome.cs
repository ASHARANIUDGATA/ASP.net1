﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication48
{
    class Program
    {
        static void Main(string[] args)
        {
            string s, rev = "";
            Console.WriteLine("enter a string");
            s = Console.ReadLine();
           for (int i =s.Length - 1; i >= 0; i--)
            {
                //Console.WriteLine(i);
                rev += s[i].ToString();
            }
            if (rev == s)
            {
                Console.WriteLine("string is palindrome");
                    }
            else
            {
                Console.WriteLine("string is not palindrome");
            }
            Console.ReadLine();


        }
    }
}
