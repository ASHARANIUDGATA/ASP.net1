﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace shape
{
    class Program
    {
        static void Main(string[] args)
        {
            Shape s1 = new Shape();
            GetData();
            Triangle t1 = new Triangle();
            double a1 = t1.Displayarea();
            Console.WriteLine("The area of Triangle" + a1);
            Rectangle r1 = new Rectangle();
            double a2 = r1.Displayarea();
            Console.WriteLine("The area of Rectangle" + a2);
            Console.ReadLine();
        }
        public static void GetData()
        {
            Console.WriteLine("Enter the length");
            double l = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the breadth");
            double b = Convert.ToDouble(Console.ReadLine());
        }
    }
    public class Shape
    {
        public double l, b;

        public virtual double Displayarea()
        {
            Console.WriteLine("finding the area");
            Console.ReadLine();
            return 0;
        }
    }
    class Triangle : Shape
    {

        public override double Displayarea()
        {

            double area = 0.5 * l * b;
            Console.WriteLine("triangle area is :" + area);
            Console.ReadLine();


           return area;
        }

    }
    class Rectangle : Shape
    {
        public override double Displayarea()
        {
            double area = l * b;
            Console.WriteLine("rectangle area is " + area);
            Console.ReadLine();
            return area;

        }

    }

}




