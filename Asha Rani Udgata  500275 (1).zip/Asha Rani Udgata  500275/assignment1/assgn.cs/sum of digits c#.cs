﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sum_of_digits
{
    class Program
    {
        static void Main(string[] args)
        
        {
            int num, sum=0, rem;
            Console.WriteLine("ENTER A NUMBER :");
          num= int.Parse(Console.ReadLine());
            while(num!=0)
            {
               
                rem = num % 10;
                num = num / 10;
                sum = sum + rem;

               
            }
            Console.WriteLine("sum of digits is" + sum);
            Console.ReadLine();
           

        }
    }
}
