﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace currency_conversion
{
    class Program
    {
        static void Main(string[] args)
        {
            double dollar, rupees;
            Console.WriteLine("enter the amount in dollar");
            dollar = Double.Parse(Console.ReadLine());
            rupees = dollar * 65.43;
            Console.WriteLine("{0} dollar equals {1} rupees", dollar, rupees);
            Console.ReadLine();
        }
    }
}
